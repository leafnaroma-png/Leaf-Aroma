import React from 'react';
import { ArrowRight, Sparkles, Award, ShieldCheck, Truck, Compass, CheckCircle2 } from 'lucide-react';
import heroBg from '../assets/images/tea_estate_hero_1788843870268.jpg';

interface HeroProps {
  onExploreProducts: () => void;
  onOpenExportInquiry: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreProducts, onOpenExportInquiry }) => {
  return (
    <section id="hero" className="relative min-h-[92vh] flex items-center pt-28 pb-16 overflow-hidden">
      {/* Background Image Container with Gradient Overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroBg}
          alt="Lush green rolling hills tea plantation in India at sunrise"
          className="w-full h-full object-cover object-center transform scale-105 transition-transform duration-1000 ease-out"
          referrerPolicy="no-referrer"
        />
        {/* Artistic Multi-stop Overlays for contrast and warmth */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#2F2113]/90 via-[#2F2113]/75 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-[#2F2113] via-transparent to-black/30"></div>
        <div className="absolute inset-0 bg-[#C89B3C]/10 mix-blend-overlay"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        <div className="max-w-2xl lg:max-w-3xl">
          {/* Tagline Pill */}
          <div className="inline-flex items-center gap-2 bg-[#F8F4E9]/15 backdrop-blur-md border border-[#C89B3C]/50 px-4 py-1.5 rounded-full mb-6">
            <Sparkles className="w-4 h-4 text-[#E2B958]" />
            <span className="text-xs sm:text-sm font-semibold tracking-wider uppercase text-[#E2B958]">
              Pure by Nature. Rich in Aroma.
            </span>
          </div>

          {/* Subheading Origin Tag */}
          <p className="text-sm sm:text-base font-medium text-amber-200/90 tracking-wide uppercase mb-3 flex items-center gap-2">
            <span className="w-8 h-[2px] bg-[#C89B3C] inline-block"></span>
            Premium Tea & Spices | Sourced from India's Finest Gardens & Farms
          </p>

          {/* Main Hero Headline */}
          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6 drop-shadow-sm">
            Experience the <span className="text-[#E2B958] italic font-normal">Authentic Taste</span> of Nature
          </h1>

          {/* Description */}
          <p className="text-base sm:text-lg text-amber-50/90 leading-relaxed mb-8 max-w-2xl font-light">
            At <strong className="font-semibold text-white">Leaf & Aroma</strong>, we bring you carefully selected premium teas and aromatic spices sourced directly from India's renowned tea estates and spice-growing regions. Every product is chosen for its purity, freshness, and exceptional quality.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-4 mb-12">
            <a
              href="#products"
              onClick={(e) => {
                e.preventDefault();
                onExploreProducts();
              }}
              className="inline-flex items-center gap-2.5 bg-[#C89B3C] hover:bg-[#A67D25] text-white px-7 py-3.5 rounded-lg text-sm sm:text-base font-semibold tracking-wide shadow-lg hover:shadow-xl transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0"
              id="hero-shop-now-btn"
            >
              <span>Shop Now</span>
              <ArrowRight className="w-4 h-4" />
            </a>

            <a
              href="#products"
              onClick={(e) => {
                e.preventDefault();
                onExploreProducts();
              }}
              className="inline-flex items-center gap-2 bg-white/15 hover:bg-white/25 text-white backdrop-blur-md border border-white/30 px-6 py-3.5 rounded-lg text-sm sm:text-base font-semibold tracking-wide transition-all duration-200"
              id="hero-explore-products-btn"
            >
              <Compass className="w-4 h-4 text-[#E2B958]" />
              <span>Explore Products</span>
            </a>

            <button
              onClick={onOpenExportInquiry}
              className="inline-flex items-center gap-2 text-amber-200 hover:text-white px-4 py-3.5 text-xs sm:text-sm font-medium tracking-wide underline underline-offset-4 decoration-[#C89B3C] hover:decoration-white transition-all"
              id="hero-b2b-inquiry-btn"
            >
              <span>Wholesale & Export Inquiry &rarr;</span>
            </button>
          </div>

          {/* Key Value Proof Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-white/20">
            <div className="flex items-center gap-2.5 text-white/95">
              <CheckCircle2 className="w-5 h-5 text-[#E2B958] flex-shrink-0" />
              <div className="text-xs">
                <span className="font-semibold block text-white">Direct Sourcing</span>
                <span className="text-amber-200/70 text-[11px]">Assam & Darjeeling</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 text-white/95">
              <Award className="w-5 h-5 text-[#E2B958] flex-shrink-0" />
              <div className="text-xs">
                <span className="font-semibold block text-white">Export Quality</span>
                <span className="text-amber-200/70 text-[11px]">Lab Certified Pure</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 text-white/95">
              <ShieldCheck className="w-5 h-5 text-[#E2B958] flex-shrink-0" />
              <div className="text-xs">
                <span className="font-semibold block text-white">Strict Inspection</span>
                <span className="text-amber-200/70 text-[11px]">Hygienic Packing</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 text-white/95">
              <Truck className="w-5 h-5 text-[#E2B958] flex-shrink-0" />
              <div className="text-xs">
                <span className="font-semibold block text-white">Global Shipping</span>
                <span className="text-amber-200/70 text-[11px]">Custom Bulk Orders</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
