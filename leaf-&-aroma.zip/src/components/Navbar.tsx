import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Mail, Globe, ShoppingBag, Send, Leaf } from 'lucide-react';
import { SampleItem } from '../types';

interface NavbarProps {
  sampleItems: SampleItem[];
  onOpenSampleDrawer: () => void;
  onOpenExportInquiry: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  sampleItems,
  onOpenSampleDrawer,
  onOpenExportInquiry
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const totalSamples = sampleItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300">
      {/* Top Announcement Bar */}
      <div className="bg-[#322314] text-[#E2B958] text-xs py-2 px-4 border-b border-[#4B3621]">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex items-center gap-2 text-center sm:text-left">
            <span className="inline-block w-2 h-2 rounded-full bg-[#C89B3C] animate-pulse"></span>
            <span className="font-medium tracking-wide">
              Direct Sourcing from India’s Renowned Tea Estates & Spice-Growing Regions
            </span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-amber-100/80">
            <a
              href="mailto:leafnaroma@gmail.com"
              className="hover:text-white flex items-center gap-1 transition-colors"
              id="topbar-email-link"
            >
              <Mail className="w-3.5 h-3.5 text-[#C89B3C]" />
              <span>leafnaroma@gmail.com</span>
            </a>
            <span className="hidden md:inline text-amber-200/30">|</span>
            <a
              href="tel:+919836305588"
              className="hover:text-white flex items-center gap-1 transition-colors"
              id="topbar-phone-link"
            >
              <Phone className="w-3.5 h-3.5 text-[#C89B3C]" />
              <span>+91-9836305588</span>
            </a>
            <span className="hidden lg:inline text-amber-200/30">|</span>
            <span className="hidden lg:flex items-center gap-1 text-[#C89B3C]">
              <Globe className="w-3.5 h-3.5" />
              <span>Worldwide Shipping</span>
            </span>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <nav
        className={`transition-all duration-300 ${
          isScrolled
            ? 'bg-[#F8F4E9]/95 backdrop-blur-md shadow-md py-3 border-b border-[#C89B3C]/20'
            : 'bg-[#F8F4E9]/90 backdrop-blur-sm py-4 border-b border-[#4B3621]/10'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Brand Logo */}
          <a href="#hero" className="flex items-center gap-3 group" id="brand-logo">
            <div className="w-10 h-10 rounded-full bg-[#4B3621] border border-[#C89B3C] flex items-center justify-center text-[#C89B3C] group-hover:scale-105 transition-transform shadow-sm">
              <Leaf className="w-5 h-5 fill-[#C89B3C]" />
            </div>
            <div>
              <span className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-[#4B3621] block leading-none">
                Leaf <span className="text-[#C89B3C] font-normal">&</span> Aroma
              </span>
              <span className="text-[10px] tracking-widest text-[#735C43] uppercase font-medium block mt-0.5">
                Pure by Nature. Rich in Aroma.
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <div className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#4B3621]">
            <a href="#about" className="hover:text-[#C89B3C] transition-colors py-1" id="nav-link-about">
              About Us
            </a>
            <a href="#products" className="hover:text-[#C89B3C] transition-colors py-1" id="nav-link-products">
              Our Products
            </a>
            <a href="#why-choose-us" className="hover:text-[#C89B3C] transition-colors py-1" id="nav-link-why">
              Why Choose Us
            </a>
            <a href="#industries" className="hover:text-[#C89B3C] transition-colors py-1" id="nav-link-industries">
              Industries
            </a>
            <a href="#gallery" className="hover:text-[#C89B3C] transition-colors py-1" id="nav-link-gallery">
              Gallery
            </a>
            <a href="#contact" className="hover:text-[#C89B3C] transition-colors py-1" id="nav-link-contact">
              Contact
            </a>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center gap-3">
            {/* Sample Request Button */}
            <button
              onClick={onOpenSampleDrawer}
              className="relative p-2.5 rounded-full text-[#4B3621] hover:text-[#C89B3C] hover:bg-[#FAF7F0] border border-[#C89B3C]/30 transition-all flex items-center gap-1.5"
              title="View Requested Samples"
              id="nav-sample-cart-btn"
            >
              <ShoppingBag className="w-5 h-5" />
              <span className="hidden sm:inline text-xs font-semibold">Samples</span>
              {totalSamples > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#C89B3C] text-white text-[11px] font-bold rounded-full flex items-center justify-center shadow-sm animate-bounce">
                  {totalSamples}
                </span>
              )}
            </button>

            {/* Export Inquiry Action Button */}
            <button
              onClick={onOpenExportInquiry}
              className="hidden sm:inline-flex items-center gap-2 bg-[#C89B3C] hover:bg-[#A67D25] text-white px-4 py-2.5 rounded-md text-xs font-semibold tracking-wider uppercase transition-all shadow-sm hover:shadow active:scale-95"
              id="nav-export-inquiry-btn"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Export Inquiry</span>
            </button>

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-md text-[#4B3621] hover:text-[#C89B3C] hover:bg-[#FAF7F0] transition-colors"
              aria-label="Toggle Menu"
              id="nav-mobile-toggle-btn"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#F8F4E9] border-b border-[#C89B3C]/30 px-6 py-5 shadow-xl animate-in slide-in-from-top duration-200">
            <div className="flex flex-col gap-4 text-base font-medium text-[#4B3621]">
              <a
                href="#about"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#C89B3C] transition-colors py-1.5 border-b border-amber-900/10"
              >
                About Us
              </a>
              <a
                href="#products"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#C89B3C] transition-colors py-1.5 border-b border-amber-900/10"
              >
                Our Products (Tea & Spices)
              </a>
              <a
                href="#why-choose-us"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#C89B3C] transition-colors py-1.5 border-b border-amber-900/10"
              >
                Why Choose Leaf & Aroma
              </a>
              <a
                href="#industries"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#C89B3C] transition-colors py-1.5 border-b border-amber-900/10"
              >
                Industries We Serve
              </a>
              <a
                href="#gallery"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#C89B3C] transition-colors py-1.5 border-b border-amber-900/10"
              >
                Estate Photo Gallery
              </a>
              <a
                href="#contact"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#C89B3C] transition-colors py-1.5"
              >
                Contact Us
              </a>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenExportInquiry();
                  }}
                  className="w-full bg-[#C89B3C] hover:bg-[#A67D25] text-white py-3 rounded-md text-sm font-semibold uppercase tracking-wider text-center"
                >
                  Request Export & Wholesale Quote
                </button>
                <div className="text-xs text-[#735C43] text-center pt-1">
                  📞 +91-9836305588 &bull; 📧 leafnaroma@gmail.com
                </div>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};
