export type ProductCategory = 'all' | 'tea' | 'spices' | 'wholesale';

export interface Product {
  id: string;
  name: string;
  category: 'tea' | 'spices';
  subcategory: string;
  tagline: string;
  origin: string;
  grade: string;
  aromaProfile: string;
  flavorNotes: string[];
  description: string;
  brewingOrUsage: string;
  packSizes: string[];
  priceEst: string;
  wholesaleAvailable: boolean;
  image: string;
  featured?: boolean;
}

export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  role: string;
  company: string;
  location: string;
  rating: number;
}

export interface InsightArticle {
  id: string;
  title: string;
  category: 'Tea Guide' | 'Spice Heritage' | 'Brewing & Storage' | 'Health & Wellness';
  date: string;
  readTime: string;
  excerpt: string;
  content: string[];
  image: string;
  author: string;
}

export interface InquiryFormData {
  fullName: string;
  email: string;
  phone: string;
  companyName?: string;
  country: string;
  inquiryType: 'Export / Wholesale' | 'Retail Order' | 'Sample Request' | 'General Inquiry';
  selectedProducts: string[];
  estimatedVolume?: string;
  message: string;
}

export interface SampleItem {
  product: Product;
  quantity: number;
  requestedPackSize: string;
}
