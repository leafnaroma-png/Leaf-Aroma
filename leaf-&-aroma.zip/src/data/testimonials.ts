import { Testimonial } from '../types';

export const testimonialsData: Testimonial[] = [
  {
    id: 'test-1',
    quote: 'Excellent quality tea with exceptional aroma. The Darjeeling FTGFOP1 and Nilgiri selections have become the hallmark of our boutique tea room in Milan.',
    author: 'Marco Rossi',
    role: 'Founder & Head Tea Sommelier',
    company: 'L’Artigiano del Tè',
    location: 'Milan, Italy',
    rating: 5
  },
  {
    id: 'test-2',
    quote: 'The aroma the moment you open the seal is incredible. The Assam CTC makes the richest, most comforting morning chai, and the whole green cardamom pods are noticeably plumper, greener, and far more fragrant than regular store packets.',
    author: 'Pooja Sharma',
    role: 'Verified Customer',
    company: 'Home Kitchen & Tea Enthusiast',
    location: 'Bengaluru, Karnataka',
    rating: 5
  },
  {
    id: 'test-3',
    quote: 'Highly recommended for wholesale tea and spice buyers. Their export paperwork, phytosanitary certifications, and nitrogen-sealed bulk packaging make international logistics completely seamless.',
    author: 'Rajesh Mehta',
    role: 'Managing Partner',
    company: 'Al-Khaleej Spice & Herb Importers',
    location: 'Dubai, United Arab Emirates',
    rating: 5
  },
  {
    id: 'test-4',
    quote: 'From sample request to delivery of two full container loads of Assam CTC and Orthodox teas, the purity, liquor density, and personal communication exceeded all expectations.',
    author: 'Evelyn Vance',
    role: 'VP Supply Chain',
    company: 'Horizon Beverage & Botanicals',
    location: 'Toronto, Canada',
    rating: 5
  }
];
