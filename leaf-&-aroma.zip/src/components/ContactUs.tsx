import React, { useState } from 'react';
import {
  MapPin,
  Mail,
  Phone,
  Globe,
  Send,
  CheckCircle2,
  Clock,
  ShieldCheck
} from 'lucide-react';

export const ContactUs: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    inquiryType: 'Export / Wholesale',
    subject: '',
    message: ''
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 600);
  };

  return (
    <section id="contact" className="py-20 bg-[#F8F4E9] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#C89B3C] mb-2">
            <span className="w-6 h-[1.5px] bg-[#C89B3C]"></span>
            <span>Get in Touch with Our Tea & Spice Masters</span>
            <span className="w-6 h-[1.5px] bg-[#C89B3C]"></span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#4B3621] tracking-tight">
            Contact Us
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#735C43] leading-relaxed">
            Whether you are seeking custom commercial container blends, retail distributor pricing, or tasting sample kits, our tea tasters and export specialists are ready to assist.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Contact Information Card */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-amber-900/10 shadow-sm">
              <div className="border-b border-amber-900/10 pb-5 mb-6">
                <h3 className="font-serif text-2xl font-bold text-[#4B3621]">
                  Leaf <span className="text-[#C89B3C]">&</span> Aroma
                </h3>
                <p className="text-xs uppercase font-semibold text-[#735C43] tracking-widest mt-1">
                  Premium Tea & Spices &bull; Estate Direct
                </p>
              </div>

              {/* Direct Info Items */}
              <div className="space-y-4 text-xs sm:text-sm text-[#4B3621]">
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-[#FAF7F0] text-[#C89B3C] flex items-center justify-center flex-shrink-0 border border-amber-900/10">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] uppercase font-bold text-[#735C43] block">Location</span>
                    <span className="font-medium">India</span>
                    <span className="text-xs text-[#735C43] block mt-0.5">
                      (Primary Operations & Estates: Kolkata Tea Hub &bull; Kochi Spice Belt)
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-[#FAF7F0] text-[#C89B3C] flex items-center justify-center flex-shrink-0 border border-amber-900/10">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] uppercase font-bold text-[#735C43] block">Official Email</span>
                    <a
                      href="mailto:leafnaroma@gmail.com"
                      className="font-medium text-[#4B3621] hover:text-[#C89B3C] transition-colors"
                      id="contact-email-link"
                    >
                      leafnaroma@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-[#FAF7F0] text-[#C89B3C] flex items-center justify-center flex-shrink-0 border border-amber-900/10">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] uppercase font-bold text-[#735C43] block">Direct Phone & WhatsApp</span>
                    <a
                      href="tel:+919836305588"
                      className="font-medium text-[#4B3621] hover:text-[#C89B3C] transition-colors"
                      id="contact-phone-link"
                    >
                      +91-9836305588
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-[#FAF7F0] text-[#C89B3C] flex items-center justify-center flex-shrink-0 border border-amber-900/10">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] uppercase font-bold text-[#735C43] block">Global Web Portal</span>
                    <a
                      href="https://www.leafandaroma.com"
                      target="_blank"
                      rel="noreferrer"
                      className="font-medium text-[#4B3621] hover:text-[#C89B3C] transition-colors"
                    >
                      www.leafandaroma.com
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Operating Hours and Trust Stamp */}
            <div className="bg-[#FAF7F0] p-5 rounded-xl border border-[#C89B3C]/30 text-xs text-[#735C43] space-y-2">
              <div className="flex items-center gap-2 font-bold text-[#4B3621]">
                <Clock className="w-4 h-4 text-[#C89B3C]" />
                <span>Operating Hours & Fast Response</span>
              </div>
              <p className="leading-relaxed">
                Monday – Saturday: 9:00 AM – 7:00 PM IST (GMT +5:30). International export inquiries received outside hours are prioritized within 12 hours.
              </p>
            </div>
          </div>

          {/* Right Secure Contact Form */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-10 rounded-2xl border border-amber-900/10 shadow-sm">
            {isSubmitted ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-[#4B3621] mb-2">
                  Message Sent Successfully
                </h3>
                <p className="text-sm text-[#735C43] max-w-md mx-auto mb-6">
                  Thank you for contacting <strong>Leaf & Aroma</strong>. Your inquiry has been routed to our specialized product manager. We will be in touch via email or phone shortly.
                </p>
                <div className="inline-block bg-[#FAF7F0] p-3 rounded-lg text-xs text-[#4B3621] mb-6">
                  Support ticket ID: <strong>LA-TKT-{Math.floor(1000 + Math.random() * 9000)}</strong>
                </div>
                <div>
                  <button
                    onClick={() => setIsSubmitted(false)}
                    className="bg-[#4B3621] text-white text-xs font-semibold px-6 py-2.5 rounded-lg hover:bg-[#322314] transition-colors"
                  >
                    Send Another Message
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5" id="secure-contact-form">
                <div className="border-b border-amber-900/10 pb-3 mb-4">
                  <h3 className="font-serif text-xl font-bold text-[#4B3621]">
                    Send Us an Inquiry
                  </h3>
                  <p className="text-xs text-[#735C43]">
                    Please share your requirements and we will promptly send catalog specs & pricing.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Elena Rostova"
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                      id="contact-name-input"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="elena@example.com"
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                      id="contact-email-input"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Phone / Mobile Number *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+1 or +91..."
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                      id="contact-phone-input"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Inquiry Category
                    </label>
                    <select
                      value={formData.inquiryType}
                      onChange={(e) => setFormData({ ...formData, inquiryType: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C]"
                      id="contact-category-select"
                    >
                      <option value="Export / Wholesale">Export / Wholesale Bulk</option>
                      <option value="Sample Kit Request">Sample Kit Request</option>
                      <option value="Retail Purchase">Retail Gourmet Purchase</option>
                      <option value="Private Label OEM">Private Label OEM Manufacturing</option>
                      <option value="General Inquiry">General Question / Feedback</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                    Subject
                  </label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="e.g. Darjeeling Second Flush & Green Cardamom Pricing"
                    className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                    Detailed Message *
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell us about your requirements, intended volumes, delivery address or questions..."
                    className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                    id="contact-message-input"
                  ></textarea>
                </div>

                <div className="flex items-center gap-2 text-[11px] text-[#735C43]">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  <span>Your privacy is protected. We will never share or sell your contact details.</span>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-[#4B3621] hover:bg-[#322314] text-white py-3.5 px-6 rounded-xl text-sm font-semibold uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-all hover:shadow"
                  id="contact-submit-btn"
                >
                  {isSubmitting ? (
                    <span>Sending Message...</span>
                  ) : (
                    <>
                      <Send className="w-4 h-4 text-[#E2B958]" />
                      <span>Send Secure Message</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
