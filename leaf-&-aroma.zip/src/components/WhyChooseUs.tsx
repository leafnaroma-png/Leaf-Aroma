import React from 'react';
import {
  Sprout,
  Award,
  ShieldCheck,
  Package,
  BadgeDollarSign,
  Globe2,
  Headphones,
  CheckCircle2,
  ChevronRight
} from 'lucide-react';

interface WhyChooseUsProps {
  onOpenExportInquiry: () => void;
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ onOpenExportInquiry }) => {
  const pillars = [
    {
      icon: Sprout,
      title: 'Direct Sourcing from Trusted Growers',
      desc: 'We bypass intermediaries by partnering directly with historic tea estates in Assam, Darjeeling, and Nilgiris, and generational spice growers across the Western Ghats.'
    },
    {
      icon: Award,
      title: 'Premium Export-Quality Products',
      desc: 'Every grade meets or exceeds stringent international phytosanitary, microbial, and maximum residue limit (MRL) standards mandated by the EU, US-FDA, and GCC.'
    },
    {
      icon: ShieldCheck,
      title: 'Strict Quality Inspection',
      desc: 'Rigorous multi-stage sensory cupping, moisture analysis, sortex grain purification, and volatile essential oil testing prior to dispatch.'
    },
    {
      icon: Package,
      title: 'Customized Bulk Orders',
      desc: 'Flexible packaging options from vacuum-sealed multi-wall export sacks and nitrogen-flushed foil bags to private label retail cartons and luxury tins.'
    },
    {
      icon: BadgeDollarSign,
      title: 'Competitive Pricing',
      desc: 'Direct-from-farm procurement models eliminate multiple distribution markups, delivering premium grade freshness at unmatched export margins.'
    },
    {
      icon: Globe2,
      title: 'Worldwide Shipping',
      desc: 'Seamless ocean freight (FCL/LCL) and expedited air cargo logistics to over 35 countries with complete customs and phytosanitary clearance documentation.'
    },
    {
      icon: Headphones,
      title: 'Reliable Customer Support',
      desc: 'Dedicated account managers offering harvest forecasting, blend consultation, sample kits within 48 hours, and 24/7 responsive coordination.'
    }
  ];

  return (
    <section id="why-choose-us" className="py-20 bg-[#FAF7F0] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Brand Thesis */}
          <div className="lg:col-span-5">
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#C89B3C] mb-2">
              <span className="w-6 h-[1.5px] bg-[#C89B3C]"></span>
              <span>Our Competitive Advantage</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#4B3621] tracking-tight leading-tight mb-6">
              Why Choose <br />
              <span className="text-[#C89B3C]">Leaf & Aroma?</span>
            </h2>
            <p className="text-base text-[#735C43] leading-relaxed mb-8">
              In an industry often crowded with prolonged warehousing and adulterated blending, Leaf & Aroma stands for radical transparency, uncompromised freshness, and dependable global trade relationships.
            </p>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-white p-4 rounded-xl border border-amber-900/10 shadow-xs">
                <span className="font-serif text-3xl font-bold text-[#4B3621] block">100%</span>
                <span className="text-xs text-[#735C43] font-medium">Estate Harvest Traceability</span>
              </div>
              <div className="bg-white p-4 rounded-xl border border-amber-900/10 shadow-xs">
                <span className="font-serif text-3xl font-bold text-[#C89B3C] block">&lt; 48h</span>
                <span className="text-xs text-[#735C43] font-medium">Sample Dispatch Worldwide</span>
              </div>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-[#C89B3C]/30 shadow-sm">
              <h4 className="font-serif text-base font-bold text-[#4B3621] mb-2 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-[#C89B3C]" />
                Ready to Expand Your Tea & Spice Line?
              </h4>
              <p className="text-xs text-[#735C43] leading-relaxed mb-4">
                Receive customized quotation sheets, lot analysis certificates, and physical cupping samples directly to your business address.
              </p>
              <button
                onClick={onOpenExportInquiry}
                className="w-full bg-[#4B3621] hover:bg-[#322314] text-white py-2.5 px-4 rounded-lg text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-xs"
              >
                <span>Request B2B Export Portfolio</span>
                <ChevronRight className="w-4 h-4 text-[#E2B958]" />
              </button>
            </div>
          </div>

          {/* Right Column: The 7 Pillars */}
          <div className="lg:col-span-7">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {pillars.map((pillar, idx) => {
                const Icon = pillar.icon;
                const isFullWidth = idx === pillars.length - 1;
                return (
                  <div
                    key={idx}
                    className={`bg-white p-5 rounded-xl border border-amber-900/10 hover:border-[#C89B3C] hover:shadow-md transition-all group ${
                      isFullWidth ? 'sm:col-span-2 bg-gradient-to-r from-white to-[#FAF7F0]' : ''
                    }`}
                  >
                    <div className="flex items-start gap-3.5">
                      <div className="w-10 h-10 rounded-lg bg-[#FAF7F0] text-[#C89B3C] group-hover:bg-[#C89B3C] group-hover:text-white transition-colors flex items-center justify-center flex-shrink-0 shadow-xs">
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                          <h3 className="font-serif text-base font-bold text-[#4B3621]">
                            {pillar.title}
                          </h3>
                        </div>
                        <p className="text-xs text-[#735C43] leading-relaxed mt-1.5">
                          {pillar.desc}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
