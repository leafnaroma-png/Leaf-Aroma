import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, Send, CheckCircle2, MessageSquare, Plus, Minus, ArrowRight } from 'lucide-react';
import { SampleItem } from '../types';

interface SampleDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  sampleItems: SampleItem[];
  onRemoveItem: (productId: string) => void;
  onUpdateQuantity: (productId: string, newQty: number) => void;
  onClearSamples: () => void;
}

export const SampleDrawer: React.FC<SampleDrawerProps> = ({
  isOpen,
  onClose,
  sampleItems,
  onRemoveItem,
  onUpdateQuantity,
  onClearSamples
}) => {
  const [shippingDetails, setShippingDetails] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    address: '',
    country: '',
    notes: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const totalItems = sampleItems.reduce((acc, item) => acc + item.quantity, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 700);
  };

  const getWhatsAppMessage = () => {
    const list = sampleItems.map((s) => `${s.quantity}x ${s.product.name} (${s.requestedPackSize})`).join(', ');
    return encodeURIComponent(
      `Hello Leaf & Aroma! I would like to request sample kits for: ${list}. Please send details.`
    );
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose}></div>

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between border-l border-amber-900/10">
          {/* Header */}
          <div className="p-5 bg-[#FAF7F0] border-b border-amber-900/10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-[#4B3621] text-[#E2B958] flex items-center justify-center">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif text-lg font-bold text-[#4B3621]">Sample Kit Request</h3>
                <span className="text-xs text-[#735C43]">
                  {totalItems} item{totalItems !== 1 ? 's' : ''} in sample kit
                </span>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full hover:bg-white text-[#4B3621] flex items-center justify-center transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-5">
            {submitted ? (
              <div className="text-center py-10">
                <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <h4 className="font-serif text-xl font-bold text-[#4B3621] mb-2">
                  Sample Request Dispatched to Lab
                </h4>
                <p className="text-xs text-[#735C43] mb-6 leading-relaxed">
                  Thank you, <strong>{shippingDetails.name}</strong>. Our dispatch team is preparing your customized vacuum-sealed sample flight. We will contact you at <strong>{shippingDetails.email}</strong> with DHL / FedEx tracking details.
                </p>
                <div className="bg-[#FAF7F0] p-3 rounded-lg text-xs text-[#4B3621] mb-6">
                  Sample Batch Ref: <strong className="text-[#C89B3C]">SMP-{Math.floor(10000 + Math.random() * 90000)}</strong>
                </div>
                <div className="space-y-2">
                  <button
                    onClick={() => {
                      onClearSamples();
                      setSubmitted(false);
                      onClose();
                    }}
                    className="w-full bg-[#4B3621] text-white py-2.5 rounded-lg text-xs font-semibold hover:bg-[#322314]"
                  >
                    Done & Return to Store
                  </button>
                </div>
              </div>
            ) : sampleItems.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-14 h-14 bg-[#FAF7F0] text-[#C89B3C] rounded-full flex items-center justify-center mx-auto mb-3">
                  <ShoppingBag className="w-6 h-6" />
                </div>
                <p className="font-serif text-base font-bold text-[#4B3621] mb-1">Your sample kit is empty</p>
                <p className="text-xs text-[#735C43] max-w-xs mx-auto mb-6">
                  Browse our tea estates and spice collections and click <strong>"Sample"</strong> to add testing quantities.
                </p>
                <button
                  onClick={onClose}
                  className="bg-[#C89B3C] hover:bg-[#A67D25] text-white px-5 py-2 rounded-lg text-xs font-semibold"
                >
                  Explore Products
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {/* List of items */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#735C43] border-b border-amber-900/10 pb-2">
                    <span>Selected Samples</span>
                    <button
                      onClick={onClearSamples}
                      className="text-xs text-red-700 hover:underline font-medium"
                    >
                      Clear All
                    </button>
                  </div>

                  {sampleItems.map((item) => (
                    <div
                      key={item.product.id}
                      className="flex items-center gap-3 p-3 bg-[#FAF7F0] rounded-xl border border-amber-900/5"
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 min-w-0">
                        <h5 className="font-serif text-xs font-bold text-[#4B3621] truncate">
                          {item.product.name}
                        </h5>
                        <p className="text-[10px] text-[#735C43] truncate">
                          {item.requestedPackSize} &bull; {item.product.origin.split(',')[0]}
                        </p>
                        <div className="flex items-center gap-2 mt-1.5">
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.product.id, Math.max(1, item.quantity - 1))}
                            className="w-5 h-5 rounded bg-white text-[#4B3621] flex items-center justify-center border border-amber-900/10 hover:bg-[#F0EBE0]"
                          >
                            <Minus className="w-2.5 h-2.5" />
                          </button>
                          <span className="text-xs font-semibold text-[#4B3621] w-4 text-center">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                            className="w-5 h-5 rounded bg-white text-[#4B3621] flex items-center justify-center border border-amber-900/10 hover:bg-[#F0EBE0]"
                          >
                            <Plus className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => onRemoveItem(item.product.id)}
                        className="text-[#735C43] hover:text-red-600 p-1 transition-colors"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Shipping & Delivery Form */}
                <form onSubmit={handleSubmit} className="space-y-3 pt-3 border-t border-amber-900/10">
                  <h4 className="font-serif text-sm font-bold text-[#4B3621]">
                    Sample Delivery Address
                  </h4>

                  <div>
                    <label className="text-[11px] font-semibold text-[#4B3621] block mb-1">
                      Recipient / Buyer Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={shippingDetails.name}
                      onChange={(e) => setShippingDetails({ ...shippingDetails, name: e.target.value })}
                      placeholder="e.g. John Miller"
                      className="w-full px-3 py-1.5 text-xs bg-[#FAF7F0] rounded-lg border border-amber-900/10 focus:outline-none focus:border-[#C89B3C]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[11px] font-semibold text-[#4B3621] block mb-1">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        value={shippingDetails.email}
                        onChange={(e) => setShippingDetails({ ...shippingDetails, email: e.target.value })}
                        placeholder="buyer@domain.com"
                        className="w-full px-3 py-1.5 text-xs bg-[#FAF7F0] rounded-lg border border-amber-900/10 focus:outline-none focus:border-[#C89B3C]"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-[#4B3621] block mb-1">
                        Phone / WhatsApp *
                      </label>
                      <input
                        type="text"
                        required
                        value={shippingDetails.phone}
                        onChange={(e) => setShippingDetails({ ...shippingDetails, phone: e.target.value })}
                        placeholder="+1 (555)..."
                        className="w-full px-3 py-1.5 text-xs bg-[#FAF7F0] rounded-lg border border-amber-900/10 focus:outline-none focus:border-[#C89B3C]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[11px] font-semibold text-[#4B3621] block mb-1">
                        Company / Business
                      </label>
                      <input
                        type="text"
                        value={shippingDetails.company}
                        onChange={(e) => setShippingDetails({ ...shippingDetails, company: e.target.value })}
                        placeholder="Tea Room / Cafe / Importer"
                        className="w-full px-3 py-1.5 text-xs bg-[#FAF7F0] rounded-lg border border-amber-900/10 focus:outline-none focus:border-[#C89B3C]"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-[#4B3621] block mb-1">
                        Destination Country *
                      </label>
                      <input
                        type="text"
                        required
                        value={shippingDetails.country}
                        onChange={(e) => setShippingDetails({ ...shippingDetails, country: e.target.value })}
                        placeholder="e.g. UK, Germany, USA"
                        className="w-full px-3 py-1.5 text-xs bg-[#FAF7F0] rounded-lg border border-amber-900/10 focus:outline-none focus:border-[#C89B3C]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-[#4B3621] block mb-1">
                      Street Address & Postal Code *
                    </label>
                    <textarea
                      rows={2}
                      required
                      value={shippingDetails.address}
                      onChange={(e) => setShippingDetails({ ...shippingDetails, address: e.target.value })}
                      placeholder="Full delivery address for courier dispatch..."
                      className="w-full px-3 py-1.5 text-xs bg-[#FAF7F0] rounded-lg border border-amber-900/10 focus:outline-none focus:border-[#C89B3C]"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full bg-[#C89B3C] hover:bg-[#A67D25] text-white py-3 rounded-lg text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-all"
                  >
                    {submitting ? (
                      <span>Dispatching Sample Request...</span>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>Confirm Sample Dispatch Request</span>
                      </>
                    )}
                  </button>
                </form>

                {/* Instant WhatsApp alternative */}
                <div className="pt-2 text-center">
                  <a
                    href={`https://wa.me/919836305588?text=${getWhatsAppMessage()}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[11px] text-emerald-700 hover:text-emerald-800 font-semibold flex items-center justify-center gap-1.5"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Send Sample List Directly via WhatsApp (+91-9836305588)</span>
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
