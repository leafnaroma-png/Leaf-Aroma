import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, Eye, Plus, Check, MapPin, Sparkles, Filter, PackageCheck } from 'lucide-react';
import { Product, ProductCategory, SampleItem } from '../types';
import { productsData } from '../data/products';

interface ProductCatalogProps {
  onSelectProduct: (product: Product) => void;
  onAddToSample: (product: Product, packSize: string) => void;
  onRequestWholesale: (product: Product) => void;
  sampleItems: SampleItem[];
}

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  onSelectProduct,
  onAddToSample,
  onRequestWholesale,
  sampleItems
}) => {
  const [activeCategory, setActiveCategory] = useState<ProductCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('all');

  const categories: { id: ProductCategory; label: string; count: number }[] = [
    { id: 'all', label: 'All Products', count: productsData.length },
    { id: 'tea', label: `Premium Tea (${productsData.filter((p) => p.category === 'tea').length})`, count: productsData.filter((p) => p.category === 'tea').length },
    { id: 'spices', label: `Premium Spices (${productsData.filter((p) => p.category === 'spices').length})`, count: productsData.filter((p) => p.category === 'spices').length },
    { id: 'wholesale', label: 'Bulk & Export Packs', count: productsData.filter((p) => p.wholesaleAvailable).length }
  ];

  const filterTags = ['all', 'Single Estate', 'Organic', 'Orthodox', 'CTC', 'Chai', 'Herbal', 'Alleppey', 'Darjeeling', 'Assam'];

  const filteredProducts = useMemo(() => {
    return productsData.filter((prod) => {
      // Category filter
      if (activeCategory === 'tea' && prod.category !== 'tea') return false;
      if (activeCategory === 'spices' && prod.category !== 'spices') return false;
      if (activeCategory === 'wholesale' && !prod.wholesaleAvailable) return false;

      // Quick Tag filter
      if (selectedTag !== 'all') {
        const matchesTag =
          prod.name.toLowerCase().includes(selectedTag.toLowerCase()) ||
          prod.subcategory.toLowerCase().includes(selectedTag.toLowerCase()) ||
          prod.origin.toLowerCase().includes(selectedTag.toLowerCase()) ||
          prod.description.toLowerCase().includes(selectedTag.toLowerCase());
        if (!matchesTag) return false;
      }

      // Search query
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const matchesQuery =
          prod.name.toLowerCase().includes(q) ||
          prod.origin.toLowerCase().includes(q) ||
          prod.grade.toLowerCase().includes(q) ||
          prod.aromaProfile.toLowerCase().includes(q) ||
          prod.flavorNotes.some((n) => n.toLowerCase().includes(q));
        if (!matchesQuery) return false;
      }

      return true;
    });
  }, [activeCategory, selectedTag, searchQuery]);

  const isInSampleList = (productId: string) => {
    return sampleItems.some((item) => item.product.id === productId);
  };

  return (
    <section id="products" className="py-20 bg-[#F8F4E9] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#C89B3C] mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Pure Botanical Selections</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#4B3621] tracking-tight">
            Our Products
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#735C43] leading-relaxed">
            Carefully curated single-estate teas and aromatic spices sourced directly from India’s foremost growing regions. Available in bespoke retail tins and containerized export bulk.
          </p>
        </div>

        {/* Filters and Search Bar Bar */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-amber-900/10 shadow-sm mb-10">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
            {/* Category Switcher Tabs */}
            <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold tracking-wide transition-all ${
                    activeCategory === cat.id
                      ? 'bg-[#4B3621] text-white shadow-xs'
                      : 'bg-[#FAF7F0] text-[#735C43] hover:text-[#4B3621] hover:bg-[#F0EBE0]'
                  }`}
                  id={`cat-btn-${cat.id}`}
                >
                  <span>{cat.label}</span>
                </button>
              ))}
            </div>

            {/* Search Input Field */}
            <div className="relative w-full lg:w-72">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#735C43]" />
              <input
                type="text"
                placeholder="Search tea, spice, origin..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] placeholder-[#735C43]/70 focus:outline-none focus:border-[#C89B3C] focus:bg-white transition-all"
                id="product-search-input"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#735C43] hover:text-[#4B3621]"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Quick Filter Tag Pills */}
          <div className="flex flex-wrap items-center gap-1.5 mt-4 pt-3 border-t border-amber-900/5 text-xs">
            <span className="text-[#735C43] font-medium mr-1 flex items-center gap-1">
              <Filter className="w-3 h-3 text-[#C89B3C]" />
              Filter Tag:
            </span>
            {filterTags.map((tag) => (
              <button
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`px-2.5 py-1 rounded-full text-[11px] font-medium capitalize transition-all ${
                  selectedTag === tag
                    ? 'bg-[#C89B3C] text-white font-semibold'
                    : 'bg-[#FAF7F0] text-[#735C43] hover:bg-[#F0EBE0]'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Results Count */}
        <div className="flex items-center justify-between mb-6 px-1">
          <p className="text-xs font-medium text-[#735C43]">
            Showing <strong className="text-[#4B3621]">{filteredProducts.length}</strong> authenticated products
          </p>
          <span className="text-xs text-[#C89B3C] font-semibold flex items-center gap-1">
            <PackageCheck className="w-3.5 h-3.5" />
            100% Export & Sample Ready
          </span>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => {
            const inSample = isInSampleList(product.id);
            return (
              <div
                key={product.id}
                className="bg-white rounded-2xl overflow-hidden border border-amber-900/10 hover:border-[#C89B3C] hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
                id={`product-card-${product.id}`}
              >
                <div>
                  {/* Card Image Container */}
                  <div className="relative h-48 overflow-hidden bg-[#FAF7F0]">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>

                    {/* Category / Origin Badges */}
                    <div className="absolute top-3 left-3">
                      <span className="bg-[#4B3621]/90 backdrop-blur-xs text-[#E2B958] text-[10px] font-bold px-2.5 py-1 rounded-md uppercase tracking-wider shadow-xs">
                        {product.category === 'tea' ? 'Estate Tea' : 'Prime Spice'}
                      </span>
                    </div>

                    {product.featured && (
                      <div className="absolute top-3 right-3">
                        <span className="bg-[#C89B3C] text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                          ★ Heritage Pick
                        </span>
                      </div>
                    )}

                    <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-white text-[11px]">
                      <span className="flex items-center gap-1 truncate text-amber-100 font-medium">
                        <MapPin className="w-3 h-3 text-[#E2B958]" />
                        <span className="truncate">{product.origin.split(',')[0]}</span>
                      </span>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-4 sm:p-5">
                    <div className="text-[11px] font-semibold text-[#C89B3C] uppercase tracking-wider mb-1">
                      {product.subcategory}
                    </div>

                    <h3 className="font-serif text-lg font-bold text-[#4B3621] leading-snug mb-1 group-hover:text-[#C89B3C] transition-colors">
                      {product.name}
                    </h3>

                    <p className="text-xs text-[#735C43] line-clamp-2 mb-3 leading-relaxed">
                      {product.tagline}
                    </p>

                    {/* Flavor Notes Tags */}
                    <div className="flex flex-wrap gap-1 mb-4">
                      {product.flavorNotes.slice(0, 3).map((note, i) => (
                        <span
                          key={i}
                          className="text-[10px] bg-[#FAF7F0] text-[#735C43] px-2 py-0.5 rounded border border-amber-900/10 font-medium"
                        >
                          {note}
                        </span>
                      ))}
                    </div>

                    {/* Grade & Pack spec */}
                    <div className="text-[11px] text-[#735C43] bg-[#FAF7F0] p-2.5 rounded-lg border border-amber-900/5 mb-2">
                      <div className="font-medium text-[#4B3621] truncate">
                        <strong>Grade:</strong> {product.grade}
                      </div>
                      <div className="text-[10px] text-[#735C43] truncate mt-0.5">
                        Packs: {product.packSizes.slice(0, 2).join(', ')}...
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="p-4 sm:p-5 pt-0 border-t border-amber-900/5 mt-auto">
                  <div className="flex items-center gap-2 pt-3">
                    <button
                      type="button"
                      onClick={() => onSelectProduct(product)}
                      className="flex-1 py-2 px-2.5 rounded-lg bg-[#FAF7F0] hover:bg-[#F0EBE0] text-[#4B3621] text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors border border-amber-900/10"
                      title="View Details and Brewing Guide"
                    >
                      <Eye className="w-3.5 h-3.5 text-[#C89B3C]" />
                      <span>Details</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onAddToSample(product, product.packSizes[0])}
                      className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
                        inSample
                          ? 'bg-emerald-700 text-white hover:bg-emerald-800'
                          : 'bg-[#C89B3C] hover:bg-[#A67D25] text-white shadow-xs'
                      }`}
                      title={inSample ? 'In your sample list' : 'Add to sample request'}
                    >
                      {inSample ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Added</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" />
                          <span>Sample</span>
                        </>
                      )}
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => onRequestWholesale(product)}
                    className="w-full mt-2 py-1.5 text-[11px] text-[#735C43] hover:text-[#C89B3C] font-medium text-center transition-colors underline underline-offset-2 decoration-[#C89B3C]/50"
                  >
                    Wholesale Inquiry &rarr;
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Empty Search Feedback */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-16 bg-white rounded-2xl border border-amber-900/10 p-8">
            <p className="text-lg font-serif font-bold text-[#4B3621] mb-2">No matching tea or spice found</p>
            <p className="text-sm text-[#735C43] mb-4">
              Try searching for "Assam", "Cardamom", "Green Tea", "Pepper", or clear your filter.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setActiveCategory('all');
                setSelectedTag('all');
              }}
              className="bg-[#C89B3C] text-white px-5 py-2 rounded-lg text-xs font-semibold"
            >
              Reset All Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
