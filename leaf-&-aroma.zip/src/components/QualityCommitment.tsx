import React, { useState } from 'react';
import {
  Sparkles,
  Wind,
  Droplets,
  ShieldCheck,
  PackageCheck,
  Globe2,
  CheckCircle2,
  FileCheck,
  Microscope,
  Flame
} from 'lucide-react';

export const QualityCommitment: React.FC = () => {
  const [activeParam, setActiveParam] = useState(0);

  const criteria = [
    {
      id: 'freshness',
      icon: Sparkles,
      title: 'Freshness',
      headline: 'Minimal Farm-to-Pack Turnaround',
      description:
        'Harvested crops are transported in climate-protected environments and processed within strict hourly windows. Our rapid vacuum containment prevents oxidative degradation of tender tea polyphenols and spice volatile resins.',
      benchmarks: ['< 72 hours from plucking to drying', 'Moisture level monitored between 4-6%', 'Direct nitrogen sealing for extended shelf-life']
    },
    {
      id: 'aroma',
      icon: Wind,
      title: 'Aroma',
      headline: 'High Volatile Essential Oil Retention',
      description:
        'Aroma is the soul of tea and spice. We employ low-temperature curing and GC-MS (Gas Chromatography-Mass Spectrometry) aroma profiling to ensure top-notes like cineole in cardamom, piperine in pepper, and muscatel esters in Darjeeling remain vibrant.',
      benchmarks: ['Alleppey Cardamom Volatile Oil: > 7.5% v/w', 'Tellicherry Pepper Piperine: > 5.5%', 'Cupping aroma intensity scored 90+ points']
    },
    {
      id: 'taste',
      icon: Droplets,
      title: 'Natural Taste',
      headline: '100% Free From Artificial Flavors & Enhancers',
      description:
        'We never spray synthetic essences, sugar glazes, or aroma additives. The rich malty cup of our Assam, the floral clarity of Nilgiri, and the clean heat of Tellicherry black pepper come purely from nature’s mineral-rich soil and sunlight.',
      benchmarks: ['Zero added coloring agents', 'Zero artificial flavoring essences', 'Natural cupping and sensory validation']
    },
    {
      id: 'purity',
      icon: ShieldCheck,
      title: 'Purity',
      headline: 'Sortex Purified & Zero Adulteration',
      description:
        'Advanced optical sortex machines and multi-tier density sieves eliminate dust, stones, husk fragments, and immature grains. Every batch is certified free of heavy metals, salmonella, and harmful microbial pathogens.',
      benchmarks: ['Sortex purity standard: 99.5%+', 'Zero pesticide residue compliance (MRL)', 'Double magnetic metal trap separation']
    },
    {
      id: 'packaging',
      icon: PackageCheck,
      title: 'Hygienic Packaging',
      headline: 'Food-Grade, Moisture & Light Barrier Enclosures',
      description:
        'All packing takes place in ISO 22000 and HACCP certified cleanrooms with positive air pressure. Products are sealed into food-grade aluminum foil, food-safe tinplate, or multi-wall kraft paper bags with inner polyethylene barriers.',
      benchmarks: ['Class 10,000 packing cleanroom standard', 'UV & moisture-resistant barrier foils', 'Tamper-evident heat seals & batch barcodes']
    },
    {
      id: 'standards',
      icon: Globe2,
      title: 'International Quality Standards',
      headline: 'Certified for Global Import Compliance',
      description:
        'Our export shipments are accompanied by official phytosanitary certificates, certificate of analysis (COA), non-GMO attestations, and compliance with European Food Safety Authority (EFSA), US-FDA, and Codex Alimentarius guidelines.',
      benchmarks: ['FSSAI & Spice Board of India Certified', 'Tea Board of India Origin Registered', 'Complete lot traceability back to plantation plot']
    }
  ];

  return (
    <section id="quality" className="py-20 bg-[#FAF7F0] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#C89B3C] mb-2">
            <span className="w-6 h-[1.5px] bg-[#C89B3C]"></span>
            <span>Zero Compromise Protocol</span>
            <span className="w-6 h-[1.5px] bg-[#C89B3C]"></span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#4B3621] tracking-tight">
            Our Quality Commitment
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#735C43] leading-relaxed">
            Every batch is carefully inspected for freshness, aroma, natural taste, purity, hygienic packaging, and international quality standards before leaving our facilities.
          </p>
        </div>

        {/* 6 Inspection Cards Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 mb-12">
          {criteria.map((item, idx) => {
            const Icon = item.icon;
            const isSelected = activeParam === idx;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveParam(idx)}
                className={`p-4 rounded-xl text-center transition-all duration-200 border flex flex-col items-center justify-center ${
                  isSelected
                    ? 'bg-[#4B3621] text-white border-[#4B3621] shadow-md scale-102'
                    : 'bg-white text-[#4B3621] border-amber-900/10 hover:border-[#C89B3C] hover:bg-[#FFFDF9]'
                }`}
                id={`quality-tab-${item.id}`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center mb-2.5 transition-colors ${
                    isSelected ? 'bg-[#C89B3C] text-white' : 'bg-[#FAF7F0] text-[#C89B3C]'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span className="font-serif text-xs sm:text-sm font-bold block">{item.title}</span>
                <span className="text-[10px] opacity-75 block mt-0.5">Step 0{idx + 1}</span>
              </button>
            );
          })}
        </div>

        {/* Detail Showcase of Active Criterion */}
        <div className="bg-white rounded-2xl p-6 sm:p-10 border border-amber-900/10 shadow-sm">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8">
              <div className="flex items-center gap-2 text-xs font-bold text-[#C89B3C] uppercase tracking-wider mb-2">
                <Microscope className="w-4 h-4" />
                <span>Inspection Parameter 0{activeParam + 1} of 06</span>
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#4B3621] mb-2">
                {criteria[activeParam].title}: <span className="text-[#C89B3C]">{criteria[activeParam].headline}</span>
              </h3>
              <p className="text-sm sm:text-base text-[#735C43] leading-relaxed mb-6">
                {criteria[activeParam].description}
              </p>

              <div className="space-y-2.5">
                <span className="text-xs font-bold uppercase tracking-wider text-[#4B3621] block">
                  Mandatory Lab Verification Benchmarks:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {criteria[activeParam].benchmarks.map((bench, bIdx) => (
                    <div
                      key={bIdx}
                      className="bg-[#FAF7F0] p-3 rounded-xl border border-amber-900/10 flex items-start gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span className="text-xs font-medium text-[#4B3621]">{bench}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="lg:col-span-4 bg-[#FAF7F0] p-6 rounded-2xl border border-[#C89B3C]/30 text-center">
              <div className="w-16 h-16 rounded-full bg-white mx-auto flex items-center justify-center text-[#C89B3C] border border-[#C89B3C]/30 shadow-xs mb-4">
                <FileCheck className="w-8 h-8" />
              </div>
              <h4 className="font-serif text-lg font-bold text-[#4B3621] mb-1">
                Certificate of Analysis (COA)
              </h4>
              <p className="text-xs text-[#735C43] mb-4">
                Included with every domestic consignment and commercial export container shipment.
              </p>
              <div className="text-[11px] font-semibold text-[#A67D25] bg-white py-1.5 px-3 rounded-md border border-amber-900/10 inline-block">
                ✓ Tested in NABL Accredited Laboratory
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
