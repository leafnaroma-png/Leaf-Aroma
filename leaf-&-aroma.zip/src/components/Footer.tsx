import React from 'react';
import { Leaf, Mail, Phone, MapPin, Globe, ShieldCheck, ArrowUp } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#322314] text-[#F8F4E9] pt-16 pb-12 border-t border-[#C89B3C]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-amber-900/30">
          {/* Brand Info */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#4B3621] border border-[#C89B3C] flex items-center justify-center text-[#C89B3C]">
                <Leaf className="w-5 h-5 fill-[#C89B3C]" />
              </div>
              <div>
                <span className="font-serif text-2xl font-bold text-white tracking-tight block">
                  Leaf <span className="text-[#C89B3C] font-normal">&</span> Aroma
                </span>
                <span className="text-[10px] tracking-widest text-[#E2B958] uppercase font-semibold">
                  Pure by Nature. Rich in Aroma.
                </span>
              </div>
            </div>

            <p className="text-xs text-amber-100/75 leading-relaxed">
              Premium Tea & Spices sourced directly from India's finest gardens & farms. Connecting discerning tea rooms, gourmet restaurants, supermarkets, and global importers with authenticated purity and harvest freshness.
            </p>

            <div className="pt-2 text-xs text-amber-200/90 space-y-1.5">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#C89B3C]" />
                <span>India (Kolkata Tea Hub &bull; Kochi Spice Hub)</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#C89B3C]" />
                <a href="mailto:leafnaroma@gmail.com" className="hover:text-white transition-colors">
                  leafnaroma@gmail.com
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#C89B3C]" />
                <a href="tel:+919836305588" className="hover:text-white transition-colors">
                  +91-9836305588
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="w-3.5 h-3.5 text-[#C89B3C]" />
                <a href="https://www.leafandaroma.com" className="hover:text-white transition-colors">
                  www.leafandaroma.com
                </a>
              </div>
            </div>
          </div>

          {/* Quick Navigation Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-serif text-sm font-bold text-white uppercase tracking-wider border-b border-[#C89B3C]/30 pb-2">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs text-amber-100/80">
              <li>
                <a href="#hero" className="hover:text-[#E2B958] transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-[#E2B958] transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#products" className="hover:text-[#E2B958] transition-colors">
                  Our Products
                </a>
              </li>
              <li>
                <a href="#why-choose-us" className="hover:text-[#E2B958] transition-colors">
                  Why Choose Us
                </a>
              </li>
              <li>
                <a href="#industries" className="hover:text-[#E2B958] transition-colors">
                  Industries We Serve
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#E2B958] transition-colors">
                  Estate Photo Gallery
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-[#E2B958] transition-colors">
                  Contact Us
                </a>
              </li>
            </ul>
          </div>

          {/* Premium Teas */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-serif text-sm font-bold text-white uppercase tracking-wider border-b border-[#C89B3C]/30 pb-2">
              Premium Teas
            </h4>
            <ul className="space-y-1.5 text-xs text-amber-100/80">
              <li>Black Tea (Whole Leaf & BOP)</li>
              <li>Green Tea (Organic Pan-Fired)</li>
              <li>Assam Tea (TGFOP & Golden Tippy)</li>
              <li>Darjeeling Tea (Muscatel FTGFOP1)</li>
              <li>Nilgiri Tea (Blue Mountain Frost)</li>
              <li>Orthodox Tea (Hand-Rolled Classic)</li>
              <li>CTC Tea (Grain Chai Blend)</li>
              <li>Imperial White Tea (Silver Needle)</li>
              <li>Herbal Tea (Tulsi Lemongrass Ginger)</li>
            </ul>
          </div>

          {/* Premium Spices & Certifications */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-serif text-sm font-bold text-white uppercase tracking-wider border-b border-[#C89B3C]/30 pb-2">
              Premium Spices
            </h4>
            <div className="flex flex-wrap gap-1.5 text-[11px] text-amber-100/80">
              <span className="bg-[#4B3621] px-2 py-0.5 rounded border border-[#C89B3C]/20">Alleppey Cardamom</span>
              <span className="bg-[#4B3621] px-2 py-0.5 rounded border border-[#C89B3C]/20">Tellicherry Pepper</span>
              <span className="bg-[#4B3621] px-2 py-0.5 rounded border border-[#C89B3C]/20">Pure Cinnamon</span>
              <span className="bg-[#4B3621] px-2 py-0.5 rounded border border-[#C89B3C]/20">Zanzibar Cloves</span>
              <span className="bg-[#4B3621] px-2 py-0.5 rounded border border-[#C89B3C]/20">Golden Turmeric</span>
              <span className="bg-[#4B3621] px-2 py-0.5 rounded border border-[#C89B3C]/20">Cochin Ginger</span>
              <span className="bg-[#4B3621] px-2 py-0.5 rounded border border-[#C89B3C]/20">Nutmeg & Mace</span>
              <span className="bg-[#4B3621] px-2 py-0.5 rounded border border-[#C89B3C]/20">Gujarat Cumin</span>
              <span className="bg-[#4B3621] px-2 py-0.5 rounded border border-[#C89B3C]/20">Coriander</span>
            </div>

            <div className="pt-3">
              <span className="text-[11px] uppercase font-bold text-[#E2B958] tracking-wider block mb-1.5">
                Compliance Standards
              </span>
              <div className="text-[11px] text-amber-100/70 space-y-1">
                <p className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#C89B3C]" />
                  <span>FSSAI & Spice Board of India Certified</span>
                </p>
                <p className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#C89B3C]" />
                  <span>Tea Board of India Registered</span>
                </p>
                <p className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#C89B3C]" />
                  <span>EU & US-FDA MRL Compliant</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Copyright and Navigation Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-amber-100/60">
          <div className="flex flex-wrap items-center gap-2">
            <a href="#hero" className="hover:text-white transition-colors">Home</a>
            <span>|</span>
            <a href="#about" className="hover:text-white transition-colors">About</a>
            <span>|</span>
            <a href="#products" className="hover:text-white transition-colors">Products</a>
            <span>|</span>
            <a href="#contact" className="hover:text-white transition-colors">Contact</a>
          </div>

          <p className="text-center sm:text-right">
            &copy; 2026 Leaf & Aroma. All Rights Reserved. Pure by Nature. Rich in Aroma.
          </p>

          <button
            onClick={scrollToTop}
            className="w-8 h-8 rounded-full bg-[#4B3621] hover:bg-[#C89B3C] text-white flex items-center justify-center transition-colors shadow-sm"
            title="Scroll to Top"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
};
