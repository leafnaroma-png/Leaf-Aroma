import React, { useState } from 'react';
import { Ship, Send, CheckCircle, Package } from 'lucide-react';
import { productsData } from '../data/products';

interface ExportInquiryProps {
  preSelectedProduct?: string | null;
}

export const ExportInquirySection: React.FC<ExportInquiryProps> = ({ preSelectedProduct }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    companyName: '',
    destinationCountry: '',
    destinationPort: '',
    shipmentVolume: '500kg - 2 Tons (LCL)',
    packagingPreference: 'Bulk Multi-Wall Export Sacks',
    incoterm: 'FOB India Port',
    selectedProducts: preSelectedProduct ? [preSelectedProduct] : ['Darjeeling Tea', 'Alleppey Green Cardamom'],
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const volumeOptions = [
    'Sample Kit (1kg - 5kg)',
    'Trial Consignment (50kg - 250kg)',
    'Commercial LCL (500kg - 2 Tons)',
    '20ft Container FCL (~6 - 10 Tons)',
    '40ft High Cube FCL (~18 - 22 Tons)'
  ];

  const packagingOptions = [
    'Bulk Multi-Wall Kraft & PE Sacks (25kg/50kg)',
    'Vacuum Foil Nitrogen Flushed Bags (5kg/10kg)',
    'Branded Metal Tins for Retail Shelves',
    'Private Label / OEM Custom Cartons'
  ];

  const incotermOptions = ['FOB India Port (Nhava Sheva / Kolkata / Cochin)', 'CIF Destination Port', 'Air Freight Expedited (CIP / CPT)'];

  const handleProductToggle = (productName: string) => {
    setFormData((prev) => {
      const exists = prev.selectedProducts.includes(productName);
      if (exists) {
        return {
          ...prev,
          selectedProducts: prev.selectedProducts.filter((p) => p !== productName)
        };
      } else {
        return {
          ...prev,
          selectedProducts: [...prev.selectedProducts, productName]
        };
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 800);
  };

  return (
    <section id="export-inquiry" className="py-20 bg-[#FAF7F0] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#C89B3C] mb-2">
            <Ship className="w-4 h-4" />
            <span>Global Commerce & Wholesale</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#4B3621] tracking-tight">
            Export & Bulk Inquiry
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#735C43] leading-relaxed">
            Direct estate container shipments and consolidated cargo to ports across Europe, North America, Middle East, and Asia-Pacific.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Info Panel */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-[#4B3621] text-white p-7 rounded-2xl shadow-lg border border-[#C89B3C]/30">
              <span className="text-xs uppercase font-bold text-[#E2B958] tracking-widest block mb-2">
                Export Advantages
              </span>
              <h3 className="font-serif text-2xl font-bold text-white mb-4">
                Seamless International Trade
              </h3>
              <p className="text-xs text-amber-100/90 leading-relaxed mb-6">
                Leaf & Aroma handles complete documentation, origin certificates, lab COAs, and phytosanitary clearances from primary loading ports in India.
              </p>

              <div className="space-y-3.5 text-xs text-amber-50">
                <div className="flex items-start gap-2.5">
                  <CheckCircle className="w-4 h-4 text-[#E2B958] flex-shrink-0 mt-0.5" />
                  <span><strong>Loading Ports:</strong> Kolkata (Tea Hub), Cochin / Nhava Sheva (Spice Hubs)</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-amber-900/10 text-xs text-[#735C43]">
              <div className="flex items-center gap-2 text-[#4B3621] font-bold text-sm mb-2">
                <Package className="w-4 h-4 text-[#C89B3C]" />
                <span>Custom Private Labeling Available</span>
              </div>
              <p className="leading-relaxed">
                We manufacture bespoke retail pyramid tea pouches, printed tins, and biodegradable standup zipper bags with your brand identity and barcode registrations.
              </p>
            </div>
          </div>

          {/* Right Form Panel */}
          <div className="lg:col-span-8 bg-white p-6 sm:p-10 rounded-2xl border border-amber-900/10 shadow-sm">
            {submitted ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-[#4B3621] mb-2">
                  Export Inquiry Received Successfully
                </h3>
                <p className="text-sm text-[#735C43] max-w-md mx-auto mb-6">
                  Thank you, <strong>{formData.fullName}</strong>. Our international export desk has received your quotation request for <strong>{formData.selectedProducts.join(', ')}</strong> ({formData.shipmentVolume}).
                </p>
                <div className="inline-block bg-[#FAF7F0] p-4 rounded-xl border border-amber-900/10 text-xs text-[#4B3621] mb-6">
                  Reference ID: <strong className="text-[#C89B3C]">EXP-LA-{Math.floor(100000 + Math.random() * 900000)}</strong> &bull; Response SLA: <strong>&lt; 24 Hours</strong>
                </div>
                <div>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="bg-[#4B3621] text-white text-xs font-semibold px-6 py-2.5 rounded-lg hover:bg-[#322314] transition-colors"
                  >
                    Submit Another Inquiry
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder="e.g. David Campbell"
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Business Email *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="name@company.com"
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Phone / WhatsApp (with Country Code) *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+1 (555) 000-0000"
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Company Name & Legal Entity
                    </label>
                    <input
                      type="text"
                      value={formData.companyName}
                      onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                      placeholder="Global Tea & Herb Imports LLC"
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Destination Country *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.destinationCountry}
                      onChange={(e) => setFormData({ ...formData, destinationCountry: e.target.value })}
                      placeholder="e.g. United Kingdom / UAE / USA"
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Destination Port / Airport
                    </label>
                    <input
                      type="text"
                      value={formData.destinationPort}
                      onChange={(e) => setFormData({ ...formData, destinationPort: e.target.value })}
                      placeholder="e.g. Port of Felixstowe / Jebel Ali / Newark"
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                    />
                  </div>
                </div>

                {/* Product Multi-select check boxes */}
                <div>
                  <label className="text-xs font-semibold text-[#4B3621] block mb-2">
                    Select Products for Quotation (Click to toggle):
                  </label>
                  <div className="max-h-40 overflow-y-auto p-3 bg-[#FAF7F0] rounded-xl border border-amber-900/10 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {productsData.map((p) => {
                      const isChecked = formData.selectedProducts.includes(p.name);
                      return (
                        <label
                          key={p.id}
                          className={`flex items-center gap-2 p-1.5 rounded-md cursor-pointer transition-colors ${
                            isChecked ? 'bg-[#C89B3C]/15 font-semibold text-[#4B3621]' : 'hover:bg-white text-[#735C43]'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => handleProductToggle(p.name)}
                            className="rounded border-amber-900/20 text-[#C89B3C] focus:ring-[#C89B3C]"
                          />
                          <span className="truncate">{p.name} ({p.category === 'tea' ? 'Tea' : 'Spice'})</span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                {/* Volume and Packaging */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Target Consignment Volume
                    </label>
                    <select
                      value={formData.shipmentVolume}
                      onChange={(e) => setFormData({ ...formData, shipmentVolume: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C]"
                    >
                      {volumeOptions.map((v) => (
                        <option key={v} value={v}>
                          {v}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                      Packaging Requirement
                    </label>
                    <select
                      value={formData.packagingPreference}
                      onChange={(e) => setFormData({ ...formData, packagingPreference: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C]"
                    >
                      {packagingOptions.map((pkg) => (
                        <option key={pkg} value={pkg}>
                          {pkg}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Incoterm preference */}
                <div>
                  <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                    Preferred Incoterms
                  </label>
                  <select
                    value={formData.incoterm}
                    onChange={(e) => setFormData({ ...formData, incoterm: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C]"
                  >
                    {incotermOptions.map((term) => (
                      <option key={term} value={term}>
                        {term}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#4B3621] block mb-1">
                    Specific Specifications, Target Price, or Custom Blending Requirements
                  </label>
                  <textarea
                    rows={3}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Provide details about mesh size, aroma intensity, target delivery timeframe, or sample requirements..."
                    className="w-full px-3.5 py-2.5 bg-[#FAF7F0] rounded-xl border border-amber-900/10 text-xs sm:text-sm text-[#4B3621] focus:outline-none focus:border-[#C89B3C] focus:bg-white"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-[#C89B3C] hover:bg-[#A67D25] text-white py-3.5 px-6 rounded-xl text-sm font-semibold uppercase tracking-wider flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all"
                  id="submit-export-inquiry-btn"
                >
                  {submitting ? (
                    <span>Processing Inquiry...</span>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Submit Export Quotation Request</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
