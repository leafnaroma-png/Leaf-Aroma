import React from 'react';
import { X, MapPin, Award, Wind, Coffee, Package, Check, Plus, ShoppingBag } from 'lucide-react';
import { Product } from '../types';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToSample: (product: Product, packSize: string) => void;
  onRequestWholesale: (product: Product) => void;
  isAlreadyInSamples?: boolean;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToSample,
  onRequestWholesale,
  isAlreadyInSamples = false
}) => {
  const [selectedPackSize, setSelectedPackSize] = React.useState<string>('');

  React.useEffect(() => {
    if (product && product.packSizes.length > 0) {
      setSelectedPackSize(product.packSizes[0]);
    }
  }, [product]);

  if (!product) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative bg-white rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl border border-amber-900/10 my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-white/80 hover:bg-white text-[#4B3621] hover:text-[#C89B3C] flex items-center justify-center transition-all shadow-md"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Product Image Column */}
          <div className="relative h-64 md:h-full min-h-[300px] bg-[#2F2113]">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#2F2113]/80 via-transparent to-transparent"></div>
            <div className="absolute bottom-4 left-4 right-4 text-white">
              <span className="inline-block bg-[#C89B3C] text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider mb-1">
                {product.category === 'tea' ? 'Estate Tea Selection' : 'Prime Spice Selection'}
              </span>
              <p className="text-xs text-amber-200/90 italic">{product.tagline}</p>
            </div>
          </div>

          {/* Product Details Column */}
          <div className="p-6 sm:p-8 flex flex-col justify-between max-h-[85vh] overflow-y-auto">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-semibold text-[#C89B3C] uppercase tracking-wider">
                  {product.subcategory}
                </span>
                <span className="text-amber-900/30">&bull;</span>
                <span className="text-xs text-[#735C43] font-medium">{product.priceEst}</span>
              </div>

              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#4B3621] mb-3">
                {product.name}
              </h3>

              <div className="space-y-2 mb-4 text-xs text-[#735C43]">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#C89B3C] flex-shrink-0" />
                  <span><strong>Origin:</strong> {product.origin}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#C89B3C] flex-shrink-0" />
                  <span><strong>Grade / Cut:</strong> {product.grade}</span>
                </div>
                <div className="flex items-start gap-2">
                  <Wind className="w-4 h-4 text-[#C89B3C] flex-shrink-0 mt-0.5" />
                  <span><strong>Aroma Profile:</strong> {product.aromaProfile}</span>
                </div>
              </div>

              {/* Flavor / Essential Notes Chips */}
              <div className="mb-4">
                <span className="text-xs font-semibold text-[#4B3621] block mb-1.5">
                  Tasting & Aroma Highlights:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {product.flavorNotes.map((note, idx) => (
                    <span
                      key={idx}
                      className="text-[11px] bg-[#FAF7F0] text-[#4B3621] px-2.5 py-0.5 rounded-full border border-[#C89B3C]/30 font-medium"
                    >
                      {note}
                    </span>
                  ))}
                </div>
              </div>

              {/* Description */}
              <p className="text-xs text-[#735C43] leading-relaxed mb-4">
                {product.description}
              </p>

              {/* Brewing / Usage Notes */}
              <div className="bg-[#FAF7F0] p-3 rounded-lg border border-[#C89B3C]/20 mb-4 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-[#4B3621] mb-1">
                  <Coffee className="w-3.5 h-3.5 text-[#C89B3C]" />
                  <span>{product.category === 'tea' ? 'Master Brewing Recommendation' : 'Culinary & Extraction Guide'}</span>
                </div>
                <p className="text-[#735C43] text-[11px] leading-relaxed">
                  {product.brewingOrUsage}
                </p>
              </div>

              {/* Pack Sizes */}
              <div className="mb-6">
                <label className="text-xs font-bold text-[#4B3621] block mb-2 flex items-center gap-1.5">
                  <Package className="w-3.5 h-3.5 text-[#C89B3C]" />
                  <span>Select Packaging / Sample Unit:</span>
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.packSizes.map((size, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedPackSize(size)}
                      className={`text-xs px-3 py-1.5 rounded-md border transition-all ${
                        selectedPackSize === size
                          ? 'border-[#C89B3C] bg-[#C89B3C] text-white font-semibold shadow-xs'
                          : 'border-amber-900/20 bg-white text-[#4B3621] hover:border-[#C89B3C]'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-4 border-t border-amber-900/10 flex flex-col sm:flex-row gap-2.5">
              <button
                type="button"
                onClick={() => {
                  onAddToSample(product, selectedPackSize || product.packSizes[0]);
                }}
                className={`flex-1 py-2.5 px-4 rounded-lg text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all ${
                  isAlreadyInSamples
                    ? 'bg-emerald-700 text-white hover:bg-emerald-800'
                    : 'bg-[#4B3621] hover:bg-[#322314] text-white shadow-xs'
                }`}
              >
                {isAlreadyInSamples ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>In Sample List</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4 text-[#E2B958]" />
                    <span>Add to Sample Kit</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  onRequestWholesale(product);
                  onClose();
                }}
                className="flex-1 py-2.5 px-4 rounded-lg text-xs font-semibold uppercase tracking-wider bg-[#C89B3C] hover:bg-[#A67D25] text-white shadow-xs flex items-center justify-center gap-2 transition-all"
              >
                <span>Export / Wholesale Quote</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
