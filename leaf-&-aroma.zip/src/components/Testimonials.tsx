import React from 'react';
import { Star, Quote, CheckCircle2 } from 'lucide-react';
import { testimonialsData } from '../data/testimonials';

export const Testimonials: React.FC = () => {
  return (
    <section className="py-20 bg-[#F8F4E9] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#C89B3C] mb-2">
            <span className="w-6 h-[1.5px] bg-[#C89B3C]"></span>
            <span>Global Partner Feedback</span>
            <span className="w-6 h-[1.5px] bg-[#C89B3C]"></span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#4B3621] tracking-tight">
            Trusted Worldwide
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#735C43] leading-relaxed">
            Here is what international tea sommeliers, gourmet retailers, and commercial spice distributors say about Leaf & Aroma.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonialsData.map((test) => (
            <div
              key={test.id}
              className="bg-white rounded-2xl p-6 border border-amber-900/10 hover:border-[#C89B3C] shadow-sm hover:shadow-md transition-all flex flex-col justify-between relative group"
            >
              <div>
                {/* 5 Stars */}
                <div className="flex items-center gap-1 text-[#C89B3C] mb-4">
                  {[...Array(test.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#C89B3C]" />
                  ))}
                </div>

                <Quote className="w-8 h-8 text-[#FAF7F0] fill-[#FAF7F0] -mt-2 mb-2 group-hover:text-[#C89B3C]/15 transition-colors" />

                <blockquote className="font-serif text-sm text-[#4B3621] font-semibold leading-relaxed mb-6 italic">
                  "{test.quote}"
                </blockquote>
              </div>

              <div className="pt-4 border-t border-amber-900/5">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-serif text-sm font-bold text-[#4B3621]">
                      {test.author}
                    </h4>
                    <p className="text-[11px] text-[#735C43]">
                      {test.role}, {test.company}
                    </p>
                    <p className="text-[10px] text-[#A67D25] font-medium">
                      📍 {test.location}
                    </p>
                  </div>
                  <div title="Verified Buyer" className="text-emerald-600">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
