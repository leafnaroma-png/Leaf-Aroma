import React, { useState } from 'react';
import { Camera, MapPin, Eye } from 'lucide-react';
import teaHero from '../assets/images/tea_estate_hero_1788843870268.jpg';
import artisanPhoto from '../assets/images/artisan_spices_tea_1788843893190.jpg';
import blackTeaCupPhoto from '../assets/images/black_tea_cup_1788845319719.jpg';
import malabarBlackPepperPhoto from '../assets/images/malabar_black_pepper_1788845812888.jpg';

interface GalleryItem {
  id: string;
  title: string;
  category: 'Gardens' | 'Harvest' | 'Spices' | 'Processing';
  location: string;
  imageUrl: string;
  caption: string;
}

export const PhotoGallery: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<string>('All');
  const [activeModalItem, setActiveModalItem] = useState<GalleryItem | null>(null);

  const galleryItems: GalleryItem[] = [
    {
      id: 'g-1',
      title: 'Sunrise Over Misty Estate Ridges',
      category: 'Gardens',
      location: 'Munnar & Darjeeling Slopes, India',
      imageUrl: teaHero,
      caption: 'Crisp morning mist rolling over cascading tea bushes at 2,100 meters above sea level.'
    },
    {
      id: 'g-2',
      title: 'Artisan Whole Spice Curing & Inspection',
      category: 'Spices',
      location: 'Idukki Western Ghats, Kerala',
      imageUrl: artisanPhoto,
      caption: 'Hand-sorted green cardamom pods, Tellicherry black peppercorns, cinnamon quills, and golden turmeric.'
    },
    {
      id: 'g-3',
      title: 'Selective Two Leaves and a Bud Plucking',
      category: 'Harvest',
      location: 'Upper Assam Tea Belt',
      imageUrl: 'https://images.unsplash.com/photo-1597481499750-3e6b22637e12?auto=format&fit=crop&w=800&q=80',
      caption: 'Skilled generational tea pluckers harvesting tender young flush tips during early dawn hours.'
    },
    {
      id: 'g-4',
      title: 'Traditional Orthodox Leaf Withering',
      category: 'Processing',
      location: 'Heritage Tea Estate Factory, Darjeeling',
      imageUrl: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80',
      caption: 'Gentle ambient air ventilation gently reducing moisture before artisan hand-rolling.'
    },
    {
      id: 'g-5',
      title: 'Sun-Drying Tellicherry Garbled Peppercorns',
      category: 'Spices',
      location: 'Malabar Coastline, Kerala',
      imageUrl: malabarBlackPepperPhoto,
      caption: 'Vine-ripened red berries turning rich ebony black under tropical sunshine.'
    },
    {
      id: 'g-6',
      title: 'Master Sensory Cupping & Quality Grading',
      category: 'Processing',
      location: 'Tasting & Evaluation Lab, Kolkata',
      imageUrl: blackTeaCupPhoto,
      caption: 'Evaluating liquor clarity, brightness, leaf infusion color, and aroma bouquet in crystal-clear glassware.'
    }
  ];

  const categories = ['All', 'Gardens', 'Harvest', 'Spices', 'Processing'];

  const filteredItems = galleryItems.filter((item) => {
    if (activeFilter === 'All') return true;
    return item.category === activeFilter;
  });

  return (
    <section id="gallery" className="py-20 bg-[#F8F4E9] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#C89B3C] mb-2">
            <Camera className="w-3.5 h-3.5" />
            <span>Visual Origin Journey</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#4B3621] tracking-tight">
            From Indian Estates to Your Cup
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#735C43] leading-relaxed">
            Take a visual walk through misty mountain gardens, sun-drenched spice farms, and precision processing floors where tradition meets hygiene.
          </p>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setActiveFilter(cat)}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
                  activeFilter === cat
                    ? 'bg-[#4B3621] text-white shadow-xs'
                    : 'bg-white text-[#735C43] border border-amber-900/10 hover:border-[#C89B3C]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveModalItem(item)}
              className="bg-white rounded-2xl overflow-hidden border border-amber-900/10 shadow-xs hover:shadow-xl transition-all duration-300 cursor-pointer group flex flex-col"
            >
              <div className="relative h-64 overflow-hidden bg-[#FAF7F0]">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>

                <div className="absolute top-3 left-3">
                  <span className="bg-[#C89B3C] text-white text-[10px] font-bold px-2.5 py-1 rounded-md uppercase tracking-wider shadow-xs">
                    {item.category}
                  </span>
                </div>

                <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-8 h-8 rounded-full bg-white/90 text-[#4B3621] flex items-center justify-center shadow-md">
                    <Eye className="w-4 h-4" />
                  </div>
                </div>

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <span className="text-[11px] text-[#E2B958] flex items-center gap-1 font-medium mb-1">
                    <MapPin className="w-3 h-3" />
                    {item.location}
                  </span>
                  <h3 className="font-serif text-base font-bold drop-shadow-xs">
                    {item.title}
                  </h3>
                </div>
              </div>

              <div className="p-4 flex-1 flex items-center justify-between text-xs text-[#735C43]">
                <p className="line-clamp-1">{item.caption}</p>
                <span className="text-[#C89B3C] font-semibold text-[11px] hover:underline flex-shrink-0 ml-2">
                  View Full
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {activeModalItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => setActiveModalItem(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative h-80 sm:h-96 bg-black">
              <img
                src={activeModalItem.imageUrl}
                alt={activeModalItem.title}
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="p-6">
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-bold text-[#C89B3C] uppercase tracking-wider">
                  {activeModalItem.category} &bull; {activeModalItem.location}
                </span>
                <button
                  onClick={() => setActiveModalItem(null)}
                  className="text-xs font-semibold text-[#735C43] hover:text-[#4B3621] px-3 py-1 bg-[#FAF7F0] rounded-md"
                >
                  Close
                </button>
              </div>
              <h3 className="font-serif text-2xl font-bold text-[#4B3621] mb-2">
                {activeModalItem.title}
              </h3>
              <p className="text-sm text-[#735C43] leading-relaxed">
                {activeModalItem.caption}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
