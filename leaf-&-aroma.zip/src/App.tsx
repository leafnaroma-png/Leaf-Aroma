import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutUs } from './components/AboutUs';
import { ProductCatalog } from './components/ProductCatalog';
import { ProductModal } from './components/ProductModal';
import { WhyChooseUs } from './components/WhyChooseUs';
import { IndustriesWeServe } from './components/IndustriesWeServe';
import { PhotoGallery } from './components/PhotoGallery';
import { Testimonials } from './components/Testimonials';
import { ExportInquirySection } from './components/ExportInquirySection';
import { ContactUs } from './components/ContactUs';
import { Footer } from './components/Footer';
import { SampleDrawer } from './components/SampleDrawer';
import { Product, SampleItem } from './types';
import { productsData } from './data/products';

export default function App() {
  // Modal states
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isSampleDrawerOpen, setIsSampleDrawerOpen] = useState(false);
  const [preSelectedExportProduct, setPreSelectedExportProduct] = useState<string | null>(null);

  // Sample items state (initially pre-populated with 2 premium picks to demonstrate instant usability)
  const [sampleItems, setSampleItems] = useState<SampleItem[]>([
    {
      product: productsData[0], // Darjeeling
      quantity: 1,
      requestedPackSize: '100g Tin'
    },
    {
      product: productsData[9], // Green Cardamom
      quantity: 1,
      requestedPackSize: '100g Glass Jar'
    }
  ]);

  // Handle adding product to sample list
  const handleAddToSample = (product: Product, packSize: string) => {
    setSampleItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1, requestedPackSize: packSize || product.packSizes[0] }];
    });
    setIsSampleDrawerOpen(true);
  };

  const handleRemoveSample = (productId: string) => {
    setSampleItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleUpdateSampleQuantity = (productId: string, newQty: number) => {
    setSampleItems((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity: newQty } : item))
    );
  };

  const handleClearSamples = () => {
    setSampleItems([]);
  };

  const handleExploreProducts = () => {
    const el = document.getElementById('products');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenExportInquiry = (product?: Product) => {
    if (product) {
      setPreSelectedExportProduct(product.name);
    }
    const el = document.getElementById('export-inquiry');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F4E9] text-[#4B3621] flex flex-col selection:bg-[#C89B3C] selection:text-white">
      {/* Sticky Header with Navigation */}
      <Navbar
        sampleItems={sampleItems}
        onOpenSampleDrawer={() => setIsSampleDrawerOpen(true)}
        onOpenExportInquiry={() => handleOpenExportInquiry()}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onExploreProducts={handleExploreProducts}
          onOpenExportInquiry={() => handleOpenExportInquiry()}
        />

        {/* About Us & Core Values */}
        <AboutUs />

        {/* Product Catalog with Categories, Search, Filters */}
        <ProductCatalog
          onSelectProduct={(product) => setSelectedProduct(product)}
          onAddToSample={handleAddToSample}
          onRequestWholesale={(product) => handleOpenExportInquiry(product)}
          sampleItems={sampleItems}
        />

        {/* Why Choose Leaf & Aroma */}
        <WhyChooseUs onOpenExportInquiry={() => handleOpenExportInquiry()} />

        {/* Industries We Serve */}
        <IndustriesWeServe onOpenExportInquiry={() => handleOpenExportInquiry()} />

        {/* Photo Gallery (Estate to Cup) */}
        <PhotoGallery />

        {/* Verified Testimonials */}
        <Testimonials />

        {/* Dedicated Export & Bulk Inquiry Section */}
        <ExportInquirySection preSelectedProduct={preSelectedExportProduct} />

        {/* Direct Contact & Details */}
        <ContactUs />
      </main>

      {/* Footer */}
      <Footer />

      {/* Product Detail Modal */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToSample={handleAddToSample}
        onRequestWholesale={(product) => handleOpenExportInquiry(product)}
        isAlreadyInSamples={
          selectedProduct ? sampleItems.some((item) => item.product.id === selectedProduct.id) : false
        }
      />

      {/* Slide-over Sample Kit Drawer */}
      <SampleDrawer
        isOpen={isSampleDrawerOpen}
        onClose={() => setIsSampleDrawerOpen(false)}
        sampleItems={sampleItems}
        onRemoveItem={handleRemoveSample}
        onUpdateQuantity={handleUpdateSampleQuantity}
        onClearSamples={handleClearSamples}
      />
    </div>
  );
}
