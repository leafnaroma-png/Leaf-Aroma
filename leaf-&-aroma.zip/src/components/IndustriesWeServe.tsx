import React from 'react';
import {
  Store,
  ShoppingCart,
  Hotel,
  Utensils,
  Coffee,
  Sparkles,
  Factory,
  Globe2,
  Check
} from 'lucide-react';

interface IndustriesWeServeProps {
  onOpenExportInquiry: () => void;
}

export const IndustriesWeServe: React.FC<IndustriesWeServeProps> = ({ onOpenExportInquiry }) => {
  const industries = [
    {
      icon: Store,
      name: 'Retail Stores',
      subtitle: 'Specialty & Gourmet Food Outlets',
      offerings: ['Premium tin packaging', 'Eye-catching shelf presence', 'Consistent batch freshness', 'Display merchandising support']
    },
    {
      icon: ShoppingCart,
      name: 'Supermarkets',
      subtitle: 'Grocery Chains & Mass Merchandisers',
      offerings: ['Private label contract manufacturing', 'High-volume barcode compliance', 'Competitive shelf margins', 'Scheduled container dispatches']
    },
    {
      icon: Hotel,
      name: 'Hotels',
      subtitle: 'Luxury Hospitality & Resorts',
      offerings: ['In-room whole leaf pyramid tea bags', 'Breakfast buffet bulk urn dispensers', 'Turndown gourmet gift packs', 'Custom estate welcome blends']
    },
    {
      icon: Utensils,
      name: 'Restaurants',
      subtitle: 'Fine Dining & Culinary Establishments',
      offerings: ['Chef-grade whole Tellicherry pepper & spices', 'High-extract culinary turmeric & cardamom', 'Pairing teas for dessert menus', 'Uniform flavor delivery']
    },
    {
      icon: Coffee,
      name: 'Cafés',
      subtitle: 'Artisan Beverage Houses & Tea Bars',
      offerings: ['Specialty Chai CTC & spice concentrates', 'Direct-origin single estate loose leaves', 'Customized house blend recipes', 'Staff brew training guides']
    },
    {
      icon: Sparkles,
      name: 'Tea Boutiques',
      subtitle: 'Connoisseur Tea Rooms & Salons',
      offerings: ['Rare First Flush Darjeeling micro-lots', 'Imperial Silver Needle white teas', 'Hand-rolled floral orthodox leaves', 'Estate provenance certificates']
    },
    {
      icon: Factory,
      name: 'Food Manufacturers',
      subtitle: 'Bakeries, Confectioners & Ready Meals',
      offerings: ['Industrial 25kg & 50kg multi-wall sacks', 'Standardized essential oil & curcumin levels', 'Microbiologically tested ingredients', 'COA per shipment lot']
    },
    {
      icon: Globe2,
      name: 'Export & Import Businesses',
      subtitle: 'International Commodity Trading Partners',
      offerings: ['FCL & LCL container loading', 'FSSAI, APEDA & Phytosanitary certifications', 'Customs documentation clearance', 'CIF / FOB ocean & air terms']
    }
  ];

  return (
    <section id="industries" className="py-20 bg-[#F8F4E9] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#C89B3C] mb-2">
            <span className="w-6 h-[1.5px] bg-[#C89B3C]"></span>
            <span>Tailored B2B Supply Solutions</span>
            <span className="w-6 h-[1.5px] bg-[#C89B3C]"></span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#4B3621] tracking-tight">
            Industries We Serve
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#735C43] leading-relaxed">
            From single-door gourmet cafes to international supermarket chains and manufacturing plants, our supply chain is engineered to meet specific commercial volumes, certifications, and packaging formats.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {industries.map((ind, idx) => {
            const Icon = ind.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl p-6 border border-amber-900/10 hover:border-[#C89B3C] hover:shadow-lg transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-[#FAF7F0] text-[#C89B3C] group-hover:bg-[#C89B3C] group-hover:text-white transition-colors flex items-center justify-center mb-4 shadow-xs">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-lg font-bold text-[#4B3621] mb-1">
                    {ind.name}
                  </h3>
                  <p className="text-xs text-[#C89B3C] font-semibold mb-4">
                    {ind.subtitle}
                  </p>

                  <ul className="space-y-2 text-xs text-[#735C43] mb-6">
                    {ind.offerings.map((item, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-[#C89B3C] flex-shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-4 border-t border-amber-900/5">
                  <button
                    onClick={onOpenExportInquiry}
                    className="w-full text-center py-2 text-xs font-semibold text-[#4B3621] hover:text-[#C89B3C] bg-[#FAF7F0] hover:bg-[#F0EBE0] rounded-lg transition-colors"
                  >
                    Inquire Supply Terms &rarr;
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
