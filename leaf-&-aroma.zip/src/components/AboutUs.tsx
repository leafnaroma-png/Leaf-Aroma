import React from 'react';
import { Award, Sprout, HeartHandshake, Trees, Smile, MapPin } from 'lucide-react';
import artisanImage from '../assets/images/artisan_spices_tea_1788843893190.jpg';

export const AboutUs: React.FC = () => {
  const values = [
    {
      icon: Award,
      title: 'Premium Quality',
      desc: 'Rigorous sensory grading, optimal moisture control, and strict purity benchmarks guarantee that every leaf and spice pod delivers world-class flavor.'
    },
    {
      icon: Sprout,
      title: 'Farm Fresh Sourcing',
      desc: 'Direct harvest procurement from single estates in Assam, Darjeeling, Nilgiris, and the Western Ghats bypasses stale warehouses for unmatched vitality.'
    },
    {
      icon: HeartHandshake,
      title: 'Ethical Procurement',
      desc: 'Transparent, equitable trade partnerships supporting generational tea pluckers and spice smallholders with fair compensation and safe working environments.'
    },
    {
      icon: Trees,
      title: 'Sustainable Practices',
      desc: 'Promoting chemical-free organic farming, soil bio-diversity preservation, eco-conscious crop rotation, and biodegradable, recyclable packaging solutions.'
    },
    {
      icon: Smile,
      title: 'Customer Satisfaction',
      desc: 'Tailored batch customization, bespoke export packaging, guaranteed dispatch timelines, and dedicated support for every partner worldwide.'
    }
  ];

  const origins = [
    { name: 'Darjeeling, West Bengal', label: 'Himalayan Altitude Teas', tag: 'First & Second Flush' },
    { name: 'Assam Valley', label: 'Brahmaputra Terroir', tag: 'Bold Malty Orthodox & CTC' },
    { name: 'Nilgiri Blue Mountains', label: 'Fragrant Highland Crops', tag: 'Brisk Aromatic Teas' },
    { name: 'Idukki & Wayanad, Kerala', label: 'Cardamom Hills & Malabar', tag: 'Green Cardamom & Tellicherry Pepper' }
  ];

  return (
    <section id="about" className="py-20 bg-[#FAF7F0] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#C89B3C] mb-2">
            <span className="w-6 h-[1.5px] bg-[#C89B3C]"></span>
            <span>About Us</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#4B3621] tracking-tight leading-tight">
            Welcome to <span className="text-[#C89B3C]">Leaf & Aroma</span>
          </h2>
          <p className="mt-4 text-lg text-[#735C43] leading-relaxed">
            Leaf & Aroma is committed to delivering premium-quality tea and spices to homes and businesses worldwide. We work closely with trusted growers to ensure every product maintains its natural flavor, aroma, and freshness.
          </p>
          <p className="mt-2 text-base text-[#735C43] leading-relaxed">
            Whether you're a retailer, wholesaler, café, hotel, or tea enthusiast, we offer products that meet international quality standards.
          </p>
        </div>

        {/* Visual Showcase & Origins */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center mb-20">
          {/* Artisan Imagery */}
          <div className="lg:col-span-7 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-xl border-4 border-white">
              <img
                src={artisanImage}
                alt="Artisan Indian spices and loose tea leaves collection on rustic wood"
                className="w-full h-[400px] sm:h-[460px] object-cover hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
              <div className="absolute bottom-6 left-6 right-6 text-white">
                <span className="bg-[#C89B3C] text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-2 inline-block">
                  Hand-Selected Harvest
                </span>
                <p className="text-base sm:text-lg font-serif font-semibold text-white drop-shadow-sm">
                  Whole spices & hand-rolled leaves picked at peak essential oil maturity
                </p>
              </div>
            </div>

            {/* Floating Origin Seal */}
            <div className="absolute -bottom-6 -right-2 sm:right-6 bg-white rounded-xl p-4 shadow-xl border border-[#C89B3C]/30 flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-[#F8F4E9] flex items-center justify-center text-[#C89B3C] border border-[#C89B3C]/40">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs uppercase tracking-wider font-semibold text-[#735C43] block">
                  Origin Authenticity
                </span>
                <span className="font-serif text-sm font-bold text-[#4B3621] block">
                  100% Indian Terroir Traceable
                </span>
              </div>
            </div>
          </div>

          {/* Regional Growing Belts */}
          <div className="lg:col-span-5 flex flex-col justify-center">
            <h3 className="font-serif text-2xl font-bold text-[#4B3621] mb-4">
              Sourced from India's Renowned Regions
            </h3>
            <p className="text-sm text-[#735C43] mb-6 leading-relaxed">
              From the high-altitude misty slopes of the Eastern Himalayas to the tropical rain forests of the Western Ghats, each region imparts distinct character, rainfall mineral profiles, and terroir to our harvests.
            </p>

            <div className="space-y-3.5">
              {origins.map((orig, i) => (
                <div
                  key={i}
                  className="bg-white p-3.5 rounded-xl border border-amber-900/10 hover:border-[#C89B3C] transition-all flex items-start gap-3 shadow-xs"
                >
                  <div className="w-8 h-8 rounded-lg bg-[#FAF7F0] flex items-center justify-center text-[#C89B3C] font-semibold text-xs flex-shrink-0 mt-0.5">
                    0{i + 1}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-sm font-bold text-[#4B3621]">{orig.name}</h4>
                      <span className="text-[10px] bg-[#FAF7F0] text-[#A67D25] font-semibold px-2 py-0.5 rounded border border-[#C89B3C]/30">
                        {orig.tag}
                      </span>
                    </div>
                    <p className="text-xs text-[#735C43] mt-0.5">{orig.label}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Our Values Section */}
        <div>
          <div className="text-center max-w-2xl mx-auto mb-12">
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#C89B3C] mb-2">
              <span>Pillars of Integrity</span>
            </div>
            <h3 className="font-serif text-3xl font-bold text-[#4B3621]">Our Core Values</h3>
            <p className="text-sm text-[#735C43] mt-2">
              Every tea chest packaged and every spice sack dispatched adheres to our five foundational principles.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            {values.map((val, idx) => {
              const IconComp = val.icon;
              return (
                <div
                  key={idx}
                  className="bg-white rounded-xl p-6 border border-amber-900/10 hover:border-[#C89B3C] hover:shadow-md transition-all flex flex-col justify-between group"
                >
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-[#FAF7F0] text-[#C89B3C] group-hover:bg-[#C89B3C] group-hover:text-white transition-colors flex items-center justify-center mb-5 shadow-xs">
                      <IconComp className="w-6 h-6" />
                    </div>
                    <h4 className="font-serif text-lg font-bold text-[#4B3621] mb-2">
                      {val.title}
                    </h4>
                    <p className="text-xs text-[#735C43] leading-relaxed">
                      {val.desc}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-amber-900/5 text-[11px] font-semibold text-[#C89B3C] flex items-center gap-1">
                    <span>Verified Commitment</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
